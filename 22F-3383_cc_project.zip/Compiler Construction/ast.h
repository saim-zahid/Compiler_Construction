#ifndef AST_H
#define AST_H

typedef struct ASTNode {
    char *label;
    int line;
    struct ASTNode *left;
    struct ASTNode *right;
} ASTNode;

#endif

