#include "semantic.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*
 * get_node_type:
 *   Recursively determine the type of an expression node using the symbol table.
 *   If an identifier is not found in the symbol table, print a semantic error.
 */
SymbolType get_node_type(ASTNode *node, ScopeStack *stack) {
    if (!node) return TYPE_INT;  // default fallback

    // Recognize boolean literals.
    if (strncmp(node->label, "true", 4) == 0 || strncmp(node->label, "false", 5) == 0)
        return TYPE_BOOL;

    // Numeric literal check.
    int hasDot = (strchr(node->label, '.') != NULL);
    int isNumeric = 1;
    for (char *p = node->label; *p; p++) {
        if (!isdigit(*p) && *p != '.' && *p != '-') {
            isNumeric = 0;
            break;
        }
    }
    if (isNumeric) {
        return hasDot ? TYPE_FLOAT : TYPE_INT;
    }

    // Check if it's an identifier.
    Symbol *sym = lookup_symbol(stack, node->label);
    if (sym) {
        return sym->type;
    } else {
        // Print error if identifier not found.
        printf("Semantic Error (line %d): Variable '%s' used before declaration.\n",
               node->line, node->label);
        return TYPE_INT;  // Return default type so analysis can continue.
    }
}

/*
 * check_assignment:
 *   Compare the type of the right-hand side with the variable's declared type.
 */
void check_assignment(ASTNode *assign_node, Symbol *sym, ScopeStack *stack) {
    SymbolType rhs_type = get_node_type(assign_node->right, stack);
    if (rhs_type != sym->type) {
        printf("Semantic Error (line %d): Type mismatch in assignment to '%s' (expected %d, got %d)\n",
               assign_node->line, sym->name, sym->type, rhs_type);
    }
}

/*
 * count_args:
 *   Count arguments in a right-leaning list.
 */
static int count_args(ASTNode *node) {
    int count = 0;
    while (node) {
        count++;
        node = node->right;
    }
    return count;
}

/*
 * check_function_call:
 *   Verify that the function is declared and has the correct arity.
 */
static void check_function_call(ASTNode *call_node, ScopeStack *stack) {
    char funcName[128];
    if (sscanf(call_node->label, "call(%127[^)])", funcName) != 1) {
        printf("Semantic Error (line %d): Invalid function call label: %s\n",
               call_node->line, call_node->label);
        return;
    }
    Symbol *func = lookup_symbol(stack, funcName);
    if (!func) {
        printf("Semantic Error (line %d): Call to undeclared function '%s'\n",
               call_node->line, funcName);
        return;
    }
    if (!func->is_function) {
        printf("Semantic Error (line %d): '%s' is not a function.\n",
               call_node->line, funcName);
        return;
    }
    // Check arity.
    int argCount = count_args(call_node->left);
    if (argCount != func->param_count) {
        printf("Semantic Error (line %d): Function '%s' expects %d args, got %d\n",
               call_node->line, funcName, func->param_count, argCount);
    }
}

/*
 * add_function_to_symtab:
 *   Insert a function symbol. Assumes the left child holds the signature (e.g., "int func")
 *   and the right child is the compound statement.
 */
static void add_function_to_symtab(ASTNode *func_decl_node, ScopeStack *stack) {
    if (!func_decl_node->left) {
        printf("Semantic Error (line %d): Function declaration missing signature.\n",
               func_decl_node->line);
        return;
    }
    // Parse the signature, e.g., "int func".
    char typeName[32], funcName[128];
    if (sscanf(func_decl_node->left->label, "%31s %127s", typeName, funcName) != 2) {
        printf("Semantic Error (line %d): Invalid function signature: %s\n",
               func_decl_node->line, func_decl_node->left->label);
        return;
    }
    
    SymbolType retType = TYPE_INT;
    if (!strcmp(typeName, "float"))
        retType = TYPE_FLOAT;
    else if (!strcmp(typeName, "bool"))
        retType = TYPE_BOOL;
    
    // Check for redeclaration.
    Symbol *existing = lookup_symbol(stack, funcName);
    if (existing) {
        printf("Semantic Error (line %d): Redeclaration of function '%s'\n",
               func_decl_node->line, funcName);
        return;
    }
    // Create the function symbol.
    Symbol *sym = create_symbol(funcName, TYPE_FUNCTION);
    sym->is_function = 1;
    sym->return_type = retType;
    // For simplicity, we assume no explicit parameter list is stored.
    insert_symbol(stack, sym);
}

/*
 * analyze_node:
 *   Traverse the AST, build the symbol table, manage scopes, and check semantics.
 */
void analyze_node(ASTNode *node, ScopeStack *stack) {
    if (!node) return;
    
    // New scope for compound statements.
    if (!strcmp(node->label, "compound")) {
        push_scope(stack);
        analyze_node(node->left, stack);
        analyze_node(node->right, stack);
        pop_scope(stack);
        return;
    }
    
    // Function declaration.
    if (!strcmp(node->label, "func_decl")) {
        add_function_to_symtab(node, stack);
        push_scope(stack);
        analyze_node(node->right, stack);
        pop_scope(stack);
        return;
    }
    
    // Variable declaration: labels like "int x", "float x", or "bool x".
    if (!strncmp(node->label, "int ", 4) ||
        !strncmp(node->label, "float ", 6) ||
        !strncmp(node->label, "bool ", 5)) {
        char typeStr[16], varName[128];
        if (sscanf(node->label, "%15s %127s", typeStr, varName) == 2) {
            Symbol *existing = lookup_symbol(stack, varName);
            if (existing) {
                printf("Semantic Error (line %d): Redeclaration of variable '%s'\n",
                       node->line, varName);
            } else {
                SymbolType varType = TYPE_INT;
                if (!strcmp(typeStr, "float"))
                    varType = TYPE_FLOAT;
                else if (!strcmp(typeStr, "bool"))
                    varType = TYPE_BOOL;
                Symbol *sym = create_symbol(varName, varType);
                insert_symbol(stack, sym);
            }
        }
    }
    
    // Assignment statement: labels like "assign(x)".
    if (!strncmp(node->label, "assign(", 7)) {
        char varName[128];
        if (sscanf(node->label, "assign(%127[^)])", varName) == 1) {
            Symbol *sym = lookup_symbol(stack, varName);
            if (!sym) {
                printf("Semantic Error (line %d): Variable '%s' used before declaration.\n",
                       node->line, varName);
            } else {
                check_assignment(node, sym, stack);
            }
        }
    }
    
    // Function call: label starts with "call(".
    if (!strncmp(node->label, "call(", 5)) {
        check_function_call(node, stack);
    }
    
    // Recurse on children.
    analyze_node(node->left, stack);
    analyze_node(node->right, stack);
}

/*
 * semantic_analysis:
 *   Entry point for semantic checking.
 */
void semantic_analysis(ASTNode *root) {
    ScopeStack *stack = create_scope_stack();
    // Push the global scope.
    push_scope(stack);
    analyze_node(root, stack);
    pop_scope(stack);
    free_scope_stack(stack);
}

