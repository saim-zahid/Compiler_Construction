#include "symtab.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

ScopeStack* create_scope_stack() {
    ScopeStack *stack = malloc(sizeof(ScopeStack));
    stack->top = NULL;
    return stack;
}

void push_scope(ScopeStack *stack) {
    Scope *new_scope = malloc(sizeof(Scope));
    new_scope->symbols = NULL;
    new_scope->next = stack->top;
    stack->top = new_scope;
}

void pop_scope(ScopeStack *stack) {
    if (!stack->top) return;
    Scope *old = stack->top;
    stack->top = old->next;

    // Free symbols in old scope.
    Symbol *sym = old->symbols;
    while (sym) {
        Symbol *tmp = sym;
        sym = sym->next;
        free(tmp->name);
        if (tmp->param_types)
            free(tmp->param_types);
        free(tmp);
    }
    free(old);
}

Symbol* create_symbol(const char *name, SymbolType type) {
    Symbol *sym = malloc(sizeof(Symbol));
    sym->name = strdup(name);
    sym->type = type;
    sym->is_function = 0;
    sym->param_count = 0;
    sym->param_types = NULL;
    sym->return_type = type;
    sym->next = NULL;
    return sym;
}

void insert_symbol(ScopeStack *stack, Symbol *sym) {
    if (!stack->top) {
        push_scope(stack);
    }
    sym->next = stack->top->symbols;
    stack->top->symbols = sym;
}

Symbol* lookup_symbol(ScopeStack *stack, const char *name) {
    for (Scope *sc = stack->top; sc != NULL; sc = sc->next) {
        for (Symbol *s = sc->symbols; s != NULL; s = s->next) {
            if (strcmp(s->name, name) == 0) {
                return s;
            }
        }
    }
    return NULL;
}

void free_scope_stack(ScopeStack *stack) {
    while (stack->top) {
        pop_scope(stack);
    }
    free(stack);
}

