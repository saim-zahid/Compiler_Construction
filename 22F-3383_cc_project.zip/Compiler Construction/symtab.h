#ifndef SYMTAB_H
#define SYMTAB_H

typedef enum {
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_FUNCTION,
} SymbolType;

typedef struct Symbol {
    char *name;
    SymbolType type;
    
    // For functions:
    int is_function;         // 1 if this symbol is a function.
    int param_count;         // Number of parameters.
    SymbolType *param_types; // Array of parameter types.
    SymbolType return_type;  // Function return type.

    // Pointer to the next symbol in the same scope.
    struct Symbol *next;
} Symbol;

// Each scope is a linked list of Symbols.
typedef struct Scope {
    Symbol *symbols;
    struct Scope *next;
} Scope;

// A stack of scopes.
typedef struct ScopeStack {
    Scope *top;
} ScopeStack;

// Symbol table functions.
ScopeStack* create_scope_stack();
void push_scope(ScopeStack *stack);
void pop_scope(ScopeStack *stack);
Symbol* create_symbol(const char *name, SymbolType type);
void insert_symbol(ScopeStack *stack, Symbol *sym);
Symbol* lookup_symbol(ScopeStack *stack, const char *name);
void free_scope_stack(ScopeStack *stack);

#endif

