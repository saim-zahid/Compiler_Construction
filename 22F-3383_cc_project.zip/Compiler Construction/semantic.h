#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "ast.h"
#include "symtab.h"

// Entry point for semantic checking.
void semantic_analysis(ASTNode *root);

// Helper functions
void analyze_node(ASTNode *node, ScopeStack *stack);
SymbolType get_node_type(ASTNode *node, ScopeStack *stack);
void check_assignment(ASTNode *assign_node, Symbol *sym, ScopeStack *stack);

#endif

